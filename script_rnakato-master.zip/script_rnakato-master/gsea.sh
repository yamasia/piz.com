#!/bin/bash

java -mx40000M -jar $(cd $(dirname $0) && pwd)/../binaries/gsea-3.0.jar 
