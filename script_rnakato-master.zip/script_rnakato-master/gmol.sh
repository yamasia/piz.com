java -Xms512m -Xmx2048m -jar /home/git/binaries/gmol_1.1.jar 
