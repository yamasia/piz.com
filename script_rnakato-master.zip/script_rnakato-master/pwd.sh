#!/bin/bash

dir=$(cd $(dirname $0) && pwd)
echo $dir